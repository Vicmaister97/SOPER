var searchData=
[
  ['inicializar_5fsemaforo',['Inicializar_Semaforo',['../d1/da6/semaforos_8c.html#a4af104b0ed37e6ae0289a1059bc6e990',1,'Inicializar_Semaforo(int semid, unsigned short *array):&#160;semaforos.c'],['../da/d94/semaforos_8h.html#a4af104b0ed37e6ae0289a1059bc6e990',1,'Inicializar_Semaforo(int semid, unsigned short *array):&#160;semaforos.c']]]
];
