var searchData=
[
  ['critical',['CRITICAL',['../d8/dbf/ejercicio6_8c.html#ae0233515480e60d29bcc731469976e02',1,'ejercicio6.c']]]
];
