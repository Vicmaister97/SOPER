var searchData=
[
  ['info',['info',['../d4/d7e/ejercicio2_8c.html#abe38599a5f0dc27643fade0d101bd87e',1,'ejercicio2.c']]]
];
