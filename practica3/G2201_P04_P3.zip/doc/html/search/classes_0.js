var searchData=
[
  ['_5finfo',['_Info',['../d1/dc7/struct___info.html',1,'']]],
  ['_5fletra',['_Letra',['../d6/dc4/struct___letra.html',1,'']]]
];
