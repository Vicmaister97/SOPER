var searchData=
[
  ['not_5fso_5fcritical',['NOT_SO_CRITICAL',['../d8/dbf/ejercicio6_8c.html#a419ecdbe18dc2955d0625aacf9a1a45a',1,'ejercicio6.c']]]
];
