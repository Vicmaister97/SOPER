var searchData=
[
  ['main',['main',['../d4/d7e/ejercicio2_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;ejercicio2.c'],['../d2/dd6/ejercicio5_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ejercicio5.c'],['../d8/dbf/ejercicio6_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;ejercicio6.c']]],
  ['manejador_5fsigusr1',['manejador_SIGUSR1',['../d4/d7e/ejercicio2_8c.html#af67f7ad6bdff3c40a6b1d97ae573fa4c',1,'ejercicio2.c']]]
];
