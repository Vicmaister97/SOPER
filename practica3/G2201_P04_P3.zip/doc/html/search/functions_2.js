var searchData=
[
  ['down_5fsemaforo',['Down_Semaforo',['../d1/da6/semaforos_8c.html#a09cfe06b86766d42e1187644784afb9b',1,'Down_Semaforo(int semid, int num_sem, int undo):&#160;semaforos.c'],['../da/d94/semaforos_8h.html#a09cfe06b86766d42e1187644784afb9b',1,'Down_Semaforo(int semid, int num_sem, int undo):&#160;semaforos.c']]]
];
